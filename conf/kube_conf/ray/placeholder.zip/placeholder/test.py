"""This is a necessary ray serve file, do not remove as Ray Serve will not start without initial serving deployment"""

from ray import serve
from fastapi import FastAPI

app = FastAPI(debug=True)


@serve.deployment
@serve.ingress(app)
class Hello:

    @app.post("/")
    def get(self):
        return ("I'd just like to interject for a moment. What you're refering to as Linux, is in fact, GNU/Linux, "
                "or as I've recently taken to calling it, GNU plus Linux. Linux is not an operating system unto "
                "itself, but rather another free component of a fully functioning GNU system made useful by the GNU "
                "corelibs, shell utilities and vital system components comprising a full OS as defined by POSIX.")


deployment = Hello.bind()
